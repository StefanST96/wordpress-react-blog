const CACHE_KEY = "posts_cache_v1";
const TTL = 5 * 60 * 1000; // 5 minuta

export const postCache = {
  get() {
    const raw = sessionStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const { posts, timestamp } = JSON.parse(raw);
    if (Date.now() - timestamp > TTL) {
      sessionStorage.removeItem(CACHE_KEY);
      return null;
    }
    return posts;
  },

  set(posts) {
    const safe = posts.slice(0, 80);
    sessionStorage.setItem(
      CACHE_KEY,
      JSON.stringify({
        posts: safe,
        timestamp: Date.now(),
      }),
    );
  },

  clear() {
    sessionStorage.removeItem(CACHE_KEY);
  },
};
